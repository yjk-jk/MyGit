<template>
  <div class="home">
    <!-- 轮播图 -->
    <el-carousel height="300px">
      <el-carousel-item v-for="(item, index) in carouselItems" :key="index">
        <img
          :src="item.image"
          alt="carousel"
          style="width: 100%; height: 300px; object-fit: cover"
        />
      </el-carousel-item>
    </el-carousel>

    <!-- 跳转到接口文档的链接 -->
    <div class="api-doc-link" style="text-align: center; margin: 20px 0">
      <a href="http://localhost:8001/swagger-ui/index.html">跳转到接口文档</a>
    </div>

    <!-- 推荐旅游景点 -->
    <div class="recommended-destinations">
      <h2 style="text-align: center">推荐旅游景点</h2>
      <el-row :gutter="20">
        <el-col :span="8" v-for="(destination, index) in destinations" :key="index">
          <el-card class="destination-card" :body-style="{ padding: '0px' }">
            <img :src="destination.image" class="image" alt="destination" />
            <div style="padding: 14px">
              <span>{{ destination.name }}</span>
              <div class="bottom">
                <el-button type="text" class="button">查看详情</el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 热门活动 -->
    <div class="hot-activities">
      <h2 style="text-align: center">热门活动</h2>
      <el-row :gutter="20">
        <el-col :span="8" v-for="(activity, index) in activities" :key="index">
          <el-card class="activity-card" :body-style="{ padding: '0px' }">
            <img :src="activity.image" class="image" alt="activity" />
            <div style="padding: 14px">
              <span>{{ activity.name }}</span>
              <div class="bottom">
                <el-button type="text" class="button">查看详情</el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>

    <!-- 新闻资讯 -->
    <div class="news-updates">
      <h2 style="text-align: center">新闻资讯</h2>
      <el-row :gutter="20">
        <el-col :span="12" v-for="(news, index) in newsItems" :key="index">
          <el-card class="news-card" shadow="hover">
            <div class="news-header">
              <h3>{{ news.title }}</h3>
              <span>{{ news.date }}</span>
            </div>
            <div class="news-content">
              <p>{{ news.summary }}</p>
            </div>
            <div class="news-footer">
              <el-button type="text" class="button">阅读更多</el-button>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Home',
  data() {
    return {
      carouselItems: [
        { image: 'http://example.com/carousel1.jpg' },
        { image: 'http://example.com/carousel2.jpg' },
        { image: 'http://example.com/carousel3.jpg' },
      ],
      destinations: [
        { name: '长城', image: 'http://example.com/destination1.jpg' },
        { name: '故宫', image: 'http://example.com/destination2.jpg' },
        { name: '天安门广场', image: 'http://example.com/destination3.jpg' },
      ],
      activities: [
        { name: '春节灯会', image: 'http://example.com/activity1.jpg' },
        { name: '中秋节赏月', image: 'http://example.com/activity2.jpg' },
        { name: '国庆节游园', image: 'http://example.com/activity3.jpg' },
      ],
      newsItems: [
        { title: '春节假期延长通知', date: '2023-01-01', summary: '春节假期将延长至1月15日...' },
        {
          title: '故宫博物院临时闭馆',
          date: '2023-02-01',
          summary: '故宫博物院将于2月1日临时闭馆...',
        },
        { title: '国庆节旅游攻略', date: '2023-09-21', summary: '国庆节期间，有哪些必玩景点...' },
      ],
    }
  },
}
</script>

<style scoped>
.home {
  padding: 20px;
}

.image {
  width: 100%;
  display: block;
}

.destination-card,
.activity-card {
  margin-bottom: 20px;
}

.news-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.news-footer {
  text-align: right;
}
</style>
