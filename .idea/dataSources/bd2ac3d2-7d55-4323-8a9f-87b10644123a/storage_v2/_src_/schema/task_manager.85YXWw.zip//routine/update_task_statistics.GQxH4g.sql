create
    definer = root@localhost procedure update_task_statistics(IN p_user_id int)
BEGIN
    DECLARE v_total_tasks INT;
    DECLARE v_completed_tasks INT;
    DECLARE v_completion_rate DECIMAL(5,2);

    SELECT COUNT(*), SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END)
    INTO v_total_tasks, v_completed_tasks
    FROM tasks
    WHERE user_id = p_user_id;

    IF v_total_tasks > 0 THEN
        SET v_completion_rate = v_completed_tasks / v_total_tasks;
    ELSE
        SET v_completion_rate = 0;
    END IF;

    INSERT INTO statistics (user_id, date, total_tasks, completed_tasks, completion_rate)
    VALUES (p_user_id, CURDATE(), v_total_tasks, v_completed_tasks, v_completion_rate)
    ON DUPLICATE KEY UPDATE
                         total_tasks = v_total_tasks,
                         completed_tasks = v_completed_tasks,
                         completion_rate = v_completion_rate;
END;

