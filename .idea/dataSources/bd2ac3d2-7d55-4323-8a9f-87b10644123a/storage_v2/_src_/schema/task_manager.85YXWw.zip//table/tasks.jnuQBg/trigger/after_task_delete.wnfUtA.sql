create definer = root@localhost trigger after_task_delete
    after delete
    on tasks
    for each row
BEGIN
    DECLARE v_total_tasks INT;
    DECLARE v_completed_tasks INT;
    DECLARE v_completion_rate DECIMAL(5,2);

    -- 计算总任务数和已完成任务数
    SELECT COUNT(*), SUM(CASE WHEN status = 'done' THEN 1 ELSE 0 END)
    INTO v_total_tasks, v_completed_tasks
    FROM tasks WHERE user_id = OLD.user_id;

    -- 计算完成率
    IF v_total_tasks > 0 THEN
        SET v_completion_rate = v_completed_tasks / v_total_tasks;
    ELSE
        SET v_completion_rate = 0;
    END IF;

    -- 更新统计记录
    INSERT INTO statistics (user_id, date, total_tasks, completed_tasks, completion_rate)
    VALUES (OLD.user_id, CURDATE(), v_total_tasks, v_completed_tasks, v_completion_rate)
    ON DUPLICATE KEY UPDATE
                         total_tasks = v_total_tasks,
                         completed_tasks = v_completed_tasks,
                         completion_rate = v_completion_rate;
END;

