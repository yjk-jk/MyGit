create definer = root@localhost trigger after_task_update
    after update
    on tasks
    for each row
BEGIN
    DECLARE v_total_tasks INT;  -- 修正1：声明必须放在BEGIN后首部
    DECLARE v_completed_tasks INT;
    DECLARE v_completion_rate DECIMAL(5,2);

    IF OLD.status != NEW.status THEN
        SELECT COUNT(*) INTO v_total_tasks FROM tasks WHERE user_id = NEW.user_id;
        SELECT COUNT(*) INTO v_completed_tasks FROM tasks WHERE user_id = NEW.user_id AND status = 'done';

        IF v_total_tasks > 0 THEN
            SET v_completion_rate = v_completed_tasks / v_total_tasks;
        ELSE
            SET v_completion_rate = 0;
        END IF;

        INSERT INTO statistics (user_id, date, total_tasks, completed_tasks, completion_rate)
        VALUES (NEW.user_id, CURDATE(), v_total_tasks, v_completed_tasks, v_completion_rate)
        ON DUPLICATE KEY UPDATE
                             total_tasks = VALUES(total_tasks),  -- 修正2：使用VALUES()函数
                             completed_tasks = VALUES(completed_tasks),
                             completion_rate = VALUES(completion_rate);
    END IF;
END;

